// YAML data (embedded) - Auto-generated
// Generated: 2025-12-15 16:34
const yamlData = {
    "metadata": {
        "language": "th-en",
        "version": 1.3,
        "updated": "2025-12-15"
    },
    "adjectives_descriptions": [
        {
            "thai": "สวย",
            "english": "beautiful",
            "transliteration": "suay"
        },
        {
            "thai": "น่าเกลียด",
            "english": "ugly",
            "transliteration": "na gliat"
        },
        {
            "thai": "มีความสุข",
            "english": "happy",
            "transliteration": "mee khwam suk"
        },
        {
            "thai": "ดีใจ",
            "english": "glad",
            "transliteration": "dee jai"
        },
        {
            "thai": "เศร้า",
            "english": "sad",
            "transliteration": "sao"
        },
        {
            "thai": "เล็ก",
            "english": "small",
            "transliteration": "lek"
        },
        {
            "thai": "ใหญ่",
            "english": "big",
            "transliteration": "yai"
        },
        {
            "thai": "ยาว",
            "english": "long",
            "transliteration": "yao"
        },
        {
            "thai": "สั้น",
            "english": "short",
            "transliteration": "san"
        },
        {
            "thai": "เร็ว",
            "english": "fast",
            "transliteration": "reaw"
        },
        {
            "thai": "ช้า",
            "english": "slow",
            "transliteration": "cha"
        },
        {
            "thai": "ร้อน",
            "english": "hot",
            "transliteration": "ron"
        },
        {
            "thai": "หนาว",
            "english": "cold (weather)",
            "transliteration": "nao"
        },
        {
            "thai": "ใกล้",
            "english": "near",
            "transliteration": "glai"
        },
        {
            "thai": "ไกล",
            "english": "far",
            "transliteration": "glai (rising)"
        },
        {
            "thai": "ใหม่",
            "english": "new",
            "transliteration": "mai"
        },
        {
            "thai": "เก่า",
            "english": "old (object)",
            "transliteration": "gao"
        },
        {
            "thai": "แก่",
            "english": "old (person)",
            "transliteration": "gae"
        },
        {
            "thai": "สกปรก",
            "english": "dirty",
            "transliteration": "sok ga brok"
        },
        {
            "thai": "สะอาด",
            "english": "clean",
            "transliteration": "sa aad"
        },
        {
            "thai": "ง่าย",
            "english": "easy",
            "transliteration": "ngai"
        },
        {
            "thai": "ยาก",
            "english": "difficult",
            "transliteration": "yak"
        },
        {
            "thai": "อร่อย",
            "english": "delicious",
            "transliteration": "a roi"
        },
        {
            "thai": "เผ็ด",
            "english": "spicy",
            "transliteration": "phet"
        },
        {
            "thai": "สาว",
            "english": "young",
            "transliteration": "sao"
        },
        {
            "thai": "ขอให้มีความสุข(ในวันเกิด)",
            "english": "wish you a happy birthday",
            "transliteration": "kaw hai me kawm suk mai wan keud"
        }
    ],
    "classifiers": [
        {
            "thai": "กระป๋อง",
            "english": "Can",
            "transliteration": "gra pong"
        },
        {
            "thai": "ใบ",
            "english": "Classifier of empty containers",
            "transliteration": "bai"
        },
        {
            "thai": "กระป๋อง 1 ใบ",
            "english": "1 empty can",
            "transliteration": "gra pong neung bai"
        },
        {
            "thai": "เบียร์ 1 กระป๋อง",
            "english": "One can of beer",
            "transliteration": "bia neung gra pong"
        },
        {
            "thai": "สี 3 กระป๋อง",
            "english": "Three cans of paint",
            "transliteration": "see saam gra pong"
        },
        {
            "thai": "หน้าต่าง 1 บาน",
            "english": "One window",
            "transliteration": "nâa-dtàang nʉ̀ng baan"
        },
        {
            "thai": "เก้าอี้ 2 ตัว",
            "english": "Two chairs",
            "transliteration": "gâo-îi sɔ̌ɔng dtua"
        },
        {
            "thai": "ต้นไม้ 1 ต้น",
            "english": "One tree",
            "transliteration": "tôn-mái nʉ̀ng dtôn"
        }
    ],
    "colors": [
        {
            "thai": "สีแดง",
            "english": "red",
            "transliteration": "see daeng"
        },
        {
            "thai": "สีน้ำเงิน",
            "english": "dark blue",
            "transliteration": "see nam ngern"
        },
        {
            "thai": "สีฟ้า",
            "english": "light blue",
            "transliteration": "see fa"
        },
        {
            "thai": "สีเขียว",
            "english": "green",
            "transliteration": "see khieow"
        },
        {
            "thai": "สีเหลือง",
            "english": "yellow",
            "transliteration": "see leuang"
        },
        {
            "thai": "สีดำ",
            "english": "black",
            "transliteration": "see dam"
        },
        {
            "thai": "สีขาว",
            "english": "white",
            "transliteration": "see khao"
        },
        {
            "thai": "สีชมพู",
            "english": "pink",
            "transliteration": "see chomphu"
        },
        {
            "thai": "สีส้ม",
            "english": "orange",
            "transliteration": "see som"
        },
        {
            "thai": "สีม่วง",
            "english": "purple",
            "transliteration": "see muang"
        },
        {
            "thai": "สีเทา",
            "english": "Grey",
            "transliteration": "see tao"
        },
        {
            "thai": "สีน้ำตาล",
            "english": "Brown",
            "transliteration": "see nam tan"
        },
        {
            "thai": "น้ำตาล",
            "english": "Sugar",
            "transliteration": "nam tan"
        }
    ],
    "company_and_work": [
        {
            "thai": "บริษัท",
            "english": "Company",
            "transliteration": "bɔɔ-rí-sàt"
        },
        {
            "thai": "บริการ",
            "english": "Service",
            "transliteration": "bɔɔ-rí-gaan"
        },
        {
            "thai": "ทำงาน",
            "english": "Work",
            "transliteration": "tham-ngaan"
        },
        {
            "thai": "สำหรับ",
            "english": "For",
            "transliteration": "sǎm-ràp"
        },
        {
            "thai": "ด้วยกัน / กัน",
            "english": "Together",
            "transliteration": "dûay-gan"
        }
    ],
    "consonants_high_class": [
        { "thai": "ข", "english": "Kăw - Kài = egg", "transliteration": "kăw kài" },
        { "thai": "ฉ", "english": "CHăw - Chìng = cymbal", "transliteration": "chăw chìng" },
        { "thai": "ฐ", "english": "Tăw - Tǎhn = foundation", "transliteration": "tăw tǎhn" },
        { "thai": "ถ", "english": "Tăw - Tôong = bag", "transliteration": "tăw tôong" },
        { "thai": "ผ", "english": "Păw - Pêung = bee", "transliteration": "păw pêung" },
        { "thai": "ฝ", "english": "Făw - Fàh = lid", "transliteration": "făw fàh" },
        { "thai": "ศ", "english": "Săw - Sàh-lah = pavilion", "transliteration": "săw sàh-lah" },
        { "thai": "ษ", "english": "Săw - Réu-sèe = hermit", "transliteration": "săw réu-sèe" },
        { "thai": "ส", "english": "Săw - Sĕuua = tiger", "transliteration": "săw sĕuua" },
        { "thai": "ห", "english": "Hăw - Hèeb = chest box", "transliteration": "hăw hèeb" }
    ],
    "consonants_low_class": [
        { "thai": "ค", "english": "Kaw - Kwai = buffalo", "transliteration": "kaw kwai" },
        { "thai": "ฅ", "english": "Kaw - Rá-kang = temple bell", "transliteration": "kaw rá-kang" },
        { "thai": "ง", "english": "NGaw - Nguu = snake", "transliteration": "ngaw nguu" },
        { "thai": "ช", "english": "CHaw - Cháng = elephant", "transliteration": "chaw cháng" },
        { "thai": "ซ", "english": "Saw - Sôh = chain", "transliteration": "saw sôh" },
        { "thai": "ฌ", "english": "CHaw - Cher = big tree", "transliteration": "chaw cher" },
        { "thai": "ญ", "english": "Yaw - Pûu-yǐng = woman", "transliteration": "yaw pûu-yǐng" },
        { "thai": "ฑ", "english": "Taw - Mohn-toh = Mandodari", "transliteration": "taw mohn-toh" },
        { "thai": "ฒ", "english": "Taw - Pûu-tâo = old man", "transliteration": "taw pûu-tâo" },
        { "thai": "ณ", "english": "Naw - Nane = novice monk", "transliteration": "naw nane" },
        { "thai": "ท", "english": "Taw - Tá-hàhn = soldier", "transliteration": "taw tá-hàhn" },
        { "thai": "ธ", "english": "Taw - Thong = flag", "transliteration": "taw thong" },
        { "thai": "น", "english": "Naw - Nŭu = mouse", "transliteration": "naw nŭu" },
        { "thai": "พ", "english": "Paw - Pahn = flower tray", "transliteration": "paw pahn" },
        { "thai": "ฟ", "english": "Faw - Fun = tooth", "transliteration": "faw fun" },
        { "thai": "ภ", "english": "Paw - Sŭm-pao = ship", "transliteration": "paw sŭm-pao" },
        { "thai": "ม", "english": "Maw - Máh = horse", "transliteration": "maw máh" },
        { "thai": "ย", "english": "Yaw - Yák = giant", "transliteration": "yaw yák" },
        { "thai": "ร", "english": "Raw - Reuua = boat", "transliteration": "raw reuua" },
        { "thai": "ล", "english": "Law - Ling = monkey", "transliteration": "law ling" },
        { "thai": "ว", "english": "Waw - Wâan = ring", "transliteration": "waw wâan" },
        { "thai": "ฬ", "english": "Law - Jòo-lah = star kite", "transliteration": "law jòo-lah" },
        { "thai": "ฮ", "english": "Haw - Nóhk-hûuk = owl", "transliteration": "haw nóhk-hûuk" }
    ],
    "consonants_middle_class": [
        { "thai": "ก", "english": "Gaw - Gài = chicken", "transliteration": "gaw gài" },
        { "thai": "จ", "english": "Jaw - Jahn = dish, plate", "transliteration": "jaw jahn" },
        { "thai": "ด", "english": "Daw - Dèk = child", "transliteration": "daw dèk" },
        { "thai": "ฎ", "english": "Daw - Chá-dah = crown", "transliteration": "daw chá-dah" },
        { "thai": "ต", "english": "DTaw - Dtào = turtle", "transliteration": "dtaw dtào" },
        { "thai": "ฏ", "english": "DTaw - Bpà-dtàk = spear", "transliteration": "dtaw bpà-dtàk" },
        { "thai": "บ", "english": "Baw - Bai-mái = leaf", "transliteration": "baw bai-mái" },
        { "thai": "ป", "english": "BPaw - Bplaa = fish", "transliteration": "bpaw bplaa" },
        { "thai": "อ", "english": "Aw - Àhng = basin", "transliteration": "aw àhng" }
    ],
    "food_and_drink": [
        {
            "thai": "อาหาร",
            "english": "food",
            "transliteration": "ahaan"
        },
        {
            "thai": "น้ำ",
            "english": "water",
            "transliteration": "nam"
        },
        {
            "thai": "กาแฟ",
            "english": "coffee",
            "transliteration": "kafae"
        },
        {
            "thai": "ชา",
            "english": "tea",
            "transliteration": "cha"
        },
        {
            "thai": "น้ำผลไม้",
            "english": "juice",
            "transliteration": "nam ponlamai"
        },
        {
            "thai": "นม",
            "english": "milk",
            "transliteration": "nom"
        },
        {
            "thai": "ผลไม้",
            "english": "fruit",
            "transliteration": "ponlamai"
        },
        {
            "thai": "ผัก",
            "english": "vegetable",
            "transliteration": "phak"
        },
        {
            "thai": "ข้าว",
            "english": "rice",
            "transliteration": "khao"
        },
        {
            "thai": "ขนมปัง",
            "english": "bread",
            "transliteration": "khanom pang"
        },
        {
            "thai": "เนื้อ",
            "english": "meat",
            "transliteration": "nuea"
        },
        {
            "thai": "ไก่",
            "english": "chicken",
            "transliteration": "gai"
        },
        {
            "thai": "ปลา",
            "english": "fish",
            "transliteration": "pla"
        },
        {
            "thai": "ไข่",
            "english": "egg",
            "transliteration": "khai"
        },
        {
            "thai": "ซุป",
            "english": "soup",
            "transliteration": "sup"
        },
        {
            "thai": "สลัด",
            "english": "salad",
            "transliteration": "salad"
        },
        {
            "thai": "แอปเปิล",
            "english": "apple",
            "transliteration": "apple"
        },
        {
            "thai": "กล้วย",
            "english": "banana",
            "transliteration": "kluay"
        },
        {
            "thai": "ส้ม",
            "english": "orange",
            "transliteration": "som"
        },
        {
            "thai": "องุ่น",
            "english": "grape",
            "transliteration": "a-ngun"
        },
        {
            "thai": "มะม่วง",
            "english": "mango",
            "transliteration": "ma muang"
        },
        {
            "thai": "มะพร้าว",
            "english": "coconut",
            "transliteration": "ma phrao"
        },
        {
            "thai": "เปลือกมะพร้าว",
            "english": "coconut shell",
            "transliteration": "plueak ma phrao"
        },
        {
            "thai": "น้ำมะพร้าว",
            "english": "coconut water",
            "transliteration": "nam ma phrao"
        },
        {
            "thai": "ธัญพืช",
            "english": "cereal / grain",
            "transliteration": "than ya pheut"
        },
        {
            "thai": "ข้าวโอ๊ต",
            "english": "oats",
            "transliteration": "khao oat"
        },
        {
            "thai": "ข้าวสาลี",
            "english": "wheat",
            "transliteration": "khao sa lee"
        },
        {
            "thai": "ข้าวโพด",
            "english": "corn",
            "transliteration": "khao pod"
        },
        {
            "thai": "ถั่ว",
            "english": "bean",
            "transliteration": "thua"
        },
        {
            "thai": "ถั่วเหลือง",
            "english": "soy",
            "transliteration": "thua leuang"
        },
        {
            "thai": "ถั่วลิสง",
            "english": "peanut",
            "transliteration": "thua li song"
        },
        {
            "thai": "ถั่วเขียว",
            "english": "mung bean",
            "transliteration": "thua khieow"
        },
        {
            "thai": "ถั่วดำ",
            "english": "black bean",
            "transliteration": "thua dam"
        },
        {
            "thai": "ถั่วแดง",
            "english": "red bean",
            "transliteration": "thua daeng"
        },
        {
            "thai": "ถั่วฝักยาว",
            "english": "long bean",
            "transliteration": "thua fak yao"
        },
        {
            "thai": "ถั่วงอก",
            "english": "bean sprout",
            "transliteration": "thua ngok"
        },
        {
            "thai": "อาหารเช้า",
            "english": "breakfast",
            "transliteration": "ahaan chao"
        },
        {
            "thai": "อาหารกลางวัน",
            "english": "lunch",
            "transliteration": "ahaan klang wan"
        },
        {
            "thai": "อาหารเย็น",
            "english": "dinner",
            "transliteration": "ahaan yen"
        },
        {
            "thai": "อากาศ",
            "english": "weather",
            "transliteration": "agat"
        },
        {
            "thai": "อาหารเช้า, ข้าวเช้า",
            "english": "breakfast",
            "transliteration": "ahan chao / khao chao"
        },
        {
            "thai": "อาหารเที่ยง, ข้าวเที่ยง",
            "english": "lunch",
            "transliteration": "ahan tiyeng / khao tiyeng"
        },
        {
            "thai": "อาหารเย็น, ข้าวเย็น",
            "english": "dinner",
            "transliteration": "ahan yen / khao yen"
        }
    ],
    "furniture": [
        {
            "thai": "เก้าอี้",
            "english": "Chair",
            "transliteration": "gâo-îi"
        },
        {
            "thai": "เก้าอี้ทำงาน",
            "english": "Office chair",
            "transliteration": "gâo-îi tham-ngaan"
        },
        {
            "thai": "เก้าอี้มีแขน",
            "english": "Armchair",
            "transliteration": "gâo-îi mii khǎen"
        },
        {
            "thai": "โซฟา / เก้าอี้โซฟา",
            "english": "Sofa",
            "transliteration": "soo-faa"
        },
        {
            "thai": "โต๊ะ",
            "english": "Table",
            "transliteration": "tó"
        },
        {
            "thai": "โต๊ะกาแฟ",
            "english": "Coffee table",
            "transliteration": "tó gaa-fae"
        },
        {
            "thai": "โต๊ะทำงาน",
            "english": "Desk (work)",
            "transliteration": "tó tham-ngaan"
        },
        {
            "thai": "โต๊ะเรียน",
            "english": "Desk (study)",
            "transliteration": "tó rian"
        },
        {
            "thai": "โต๊ะอาหาร",
            "english": "Dining table",
            "transliteration": "tó aa-hǎan"
        },
        {
            "thai": "โต๊ะข้าง",
            "english": "Side table",
            "transliteration": "tó khâang"
        },
        {
            "thai": "โต๊ะข้างเตียง",
            "english": "Bed stool",
            "transliteration": "tó khâang dtiang"
        },
        {
            "thai": "โต๊ะใหญ่",
            "english": "Big table",
            "transliteration": "tó yài"
        },
        {
            "thai": "โต๊ะกลม",
            "english": "Round table",
            "transliteration": "tó glom"
        },
        {
            "thai": "ชั้น",
            "english": "Shelf / Level",
            "transliteration": "chán"
        },
        {
            "thai": "ชั้นหนังสือ",
            "english": "Bookcase",
            "transliteration": "chán năng-sʉ̌ʉ"
        },
        {
            "thai": "ตู้",
            "english": "Cabinet",
            "transliteration": "tûu"
        }
    ],
    "greetings_and_basic_expressions": [
        {
            "thai": "สวัสดี",
            "english": "Hello",
            "transliteration": "sa-wat-dee"
        },
        {
            "thai": "เป็นไงบ้าง",
            "english": "How are you?",
            "transliteration": "bpen ngai bang"
        },
        {
            "thai": "สบายดี",
            "english": "I’m fine",
            "transliteration": "sa-bai dee"
        },
        {
            "thai": "ก็ดี",
            "english": "I’m good",
            "transliteration": "gaw dee"
        },
        {
            "thai": "เฉยๆ",
            "english": "so-so",
            "transliteration": "choey choey"
        },
        {
            "thai": "ไม่ค่อยดี",
            "english": "Not so good",
            "transliteration": "mai koi dee"
        },
        {
            "thai": "ขอบคุณ",
            "english": "Thank you",
            "transliteration": "khob khun"
        },
        {
            "thai": "ขอบคุณมาก",
            "english": "Thank you very much",
            "transliteration": "khob khun mak"
        },
        {
            "thai": "ขอโทษ",
            "english": "Sorry / Excuse me",
            "transliteration": "kho thot"
        },
        {
            "thai": "ไม่เป็นไร",
            "english": "It’s okay / No problem",
            "transliteration": "mai bpen rai"
        },
        {
            "thai": "ช่วยด้วย",
            "english": "Help!",
            "transliteration": "chuay duay"
        },
        {
            "thai": "[ผม/ฉัน]ไม่เข้าใจ",
            "english": "I don’t understand",
            "transliteration": "chan mai kao jai"
        },
        {
            "thai": "เข้าใจ",
            "english": "Understand",
            "transliteration": "kao jai"
        },
        {
            "thai": "ใช่",
            "english": "Yes",
            "transliteration": "chai"
        },
        {
            "thai": "ไม่ใช่",
            "english": "No / Is not",
            "transliteration": "mai chai"
        },
        {
            "thai": "ได้",
            "english": "Can / OK",
            "transliteration": "dai"
        },
        {
            "thai": "ไม่ได้",
            "english": "Cannot / Did not",
            "transliteration": "mai dai"
        },
        {
            "thai": "ลาก่อน",
            "english": "Goodbye",
            "transliteration": "la gon"
        },
        {
            "thai": "และก็",
            "english": "So-so",
            "transliteration": "lae gaw"
        },
        {
            "thai": "อย่างไหน",
            "english": "which way",
            "transliteration": "yang nai"
        },
        {
            "thai": "ชีวิตดี",
            "english": "Good life",
            "transliteration": "chee weet dee"
        },
        {
            "thai": "โชคดี",
            "english": "good lucj",
            "transliteration": "chock dee"
        },
        {
            "thai": "ยังไม่กิน",
            "english": "not eaten yet",
            "transliteration": "yang mai khin"
        }
    ],
    "machines": [
        {
            "thai": "เครื่อง",
            "english": "Classifier (machine)",
            "transliteration": "khrʉ̂ang"
        },
        {
            "thai": "คอมพิวเตอร์",
            "english": "Computer",
            "transliteration": "khom-phiúu-dter"
        }
    ],
    "media_and_entertainment": [
        {
            "thai": "เพลง",
            "english": "song",
            "transliteration": "pleng"
        },
        {
            "thai": "หนัง",
            "english": "movie",
            "transliteration": "nang"
        },
        {
            "thai": "หนังสือ",
            "english": "book",
            "transliteration": "nangsue"
        },
        {
            "thai": "ข่าว",
            "english": "news",
            "transliteration": "khao"
        },
        {
            "thai": "ดนตรี",
            "english": "music",
            "transliteration": "don tree"
        }
    ],
    "nature_and_sports": [
        {
            "thai": "ต้นไม้",
            "english": "Tree / Plant",
            "transliteration": "tôn-mái"
        },
        {
            "thai": "ต้น",
            "english": "Classifier (tree/plant)",
            "transliteration": "dtôn"
        },
        {
            "thai": "สนาม",
            "english": "Field / Court",
            "transliteration": "sà-nǎam"
        },
        {
            "thai": "สนามฟุตบอล",
            "english": "Football field",
            "transliteration": "sà-nǎam fút-bon"
        },
        {
            "thai": "สนามวอลเล่ย์บอล",
            "english": "Volleyball court",
            "transliteration": "sà-nǎam won-lêe-bon"
        },
        {
            "thai": "สนามบาสเกตบอล",
            "english": "Basketball court",
            "transliteration": "sà-nǎam bàs-gèt-bon"
        },
        {
            "thai": "สนามบิน",
            "english": "Airport",
            "transliteration": "sà-nǎam-bin"
        }
    ],
    "numbers": [
        {
            "thai": "ศูนย์",
            "english": "zero",
            "transliteration": "soon"
        },
        {
            "thai": "หนึ่ง",
            "english": "one",
            "transliteration": "neung"
        },
        {
            "thai": "สอง",
            "english": "two",
            "transliteration": "song"
        },
        {
            "thai": "สาม",
            "english": "three",
            "transliteration": "sam"
        },
        {
            "thai": "สี่",
            "english": "four",
            "transliteration": "see"
        },
        {
            "thai": "ห้า",
            "english": "five",
            "transliteration": "ha"
        },
        {
            "thai": "หก",
            "english": "six",
            "transliteration": "hok"
        },
        {
            "thai": "เจ็ด",
            "english": "seven",
            "transliteration": "jet"
        },
        {
            "thai": "แปด",
            "english": "eight",
            "transliteration": "paet"
        },
        {
            "thai": "เก้า",
            "english": "nine",
            "transliteration": "gao"
        },
        {
            "thai": "สิบ",
            "english": "ten",
            "transliteration": "sib"
        }
    ],
    "occupations": [
        {
            "thai": "นักเรียน",
            "english": "student",
            "transliteration": "nak rian"
        },
        {
            "thai": "ครู",
            "english": "teacher",
            "transliteration": "kru"
        },
        {
            "thai": "หมอ",
            "english": "doctor",
            "transliteration": "mor"
        },
        {
            "thai": "พยาบาล",
            "english": "nurse",
            "transliteration": "phaya ban"
        },
        {
            "thai": "วิศวกร",
            "english": "engineer",
            "transliteration": "wit sa wa kon"
        },
        {
            "thai": "ทนายความ",
            "english": "lawyer",
            "transliteration": "tha nay khwam"
        },
        {
            "thai": "ตำรวจ",
            "english": "police officer",
            "transliteration": "tam ruat"
        },
        {
            "thai": "นักดับเพลิง",
            "english": "firefighter",
            "transliteration": "nak dap plerng"
        },
        {
            "thai": "พ่อครัว",
            "english": "chef (male)",
            "transliteration": "por krua"
        },
        {
            "thai": "แม่ครัว",
            "english": "chef (female)",
            "transliteration": "mae krua"
        },
        {
            "thai": "พนักงานเสิร์ฟ",
            "english": "waiter / waitress",
            "transliteration": "pha nak ngaan serb"
        },
        {
            "thai": "นักเขียน",
            "english": "writer",
            "transliteration": "nak kian"
        },
        {
            "thai": "นักอ่าน",
            "english": "reader",
            "transliteration": "nak an"
        },
        {
            "thai": "พนักงาน",
            "english": "staff / employee",
            "transliteration": "pha nak ngaan"
        },
        {
            "thai": "พนักงานเสิร์ฟหญิง",
            "english": "Waitress",
            "transliteration": "pa nak ngan serb ying"
        },
        {
            "thai": "ศิลปิน",
            "english": "Artist",
            "transliteration": "si la pin"
        },
        {
            "thai": "นักดนตรี",
            "english": "Musician",
            "transliteration": "nak don tree"
        },
        {
            "thai": "นักร้อง",
            "english": "Singer",
            "transliteration": "nak rawng"
        },
        {
            "thai": "นักแสดง",
            "english": "Actor",
            "transliteration": "nak sa daeng"
        },
        {
            "thai": "ช่างภาพ",
            "english": "Photographer",
            "transliteration": "chang phap"
        },
        {
            "thai": "นักออกแบบ",
            "english": "Designer",
            "transliteration": "nak awk baeb"
        },
        {
            "thai": "สถาปนิก",
            "english": "Architect",
            "transliteration": "sa tha pa nik"
        },
        {
            "thai": "นักวิทยาศาสตร์",
            "english": "Scientist",
            "transliteration": "nak wit tha ya sat"
        },
        {
            "thai": "นักวิจัย",
            "english": "Researcher",
            "transliteration": "nak wi jai"
        },
        {
            "thai": "นักบัญชี",
            "english": "Accountant",
            "transliteration": "nak ban chee"
        },
        {
            "thai": "ผู้จัดการ",
            "english": "Manager",
            "transliteration": "phu jad gan"
        },
        {
            "thai": "เลขานุการ",
            "english": "Secretary",
            "transliteration": "le kha nu kan"
        },
        {
            "thai": "ผู้ประกอบการ",
            "english": "Entrepreneur",
            "transliteration": "phu pra gob gan"
        },
        {
            "thai": "พนักงานขาย",
            "english": "Salesperson",
            "transliteration": "pa nak ngan kai"
        },
        {
            "thai": "แคชเชียร์",
            "english": "Cashier",
            "transliteration": "cashier"
        },
        {
            "thai": "บาริสต้า",
            "english": "Barista",
            "transliteration": "ba ri sta"
        },
        {
            "thai": "คนขับรถ",
            "english": "Driver",
            "transliteration": "khon khap rot"
        },
        {
            "thai": "ชาวนา",
            "english": "Farmer",
            "transliteration": "chao na"
        },
        {
            "thai": "ช่างเครื่อง",
            "english": "Mechanic",
            "transliteration": "chang khreuang"
        },
        {
            "thai": "ช่างไฟ",
            "english": "Electrician",
            "transliteration": "chang fai"
        },
        {
            "thai": "ช่างประปา",
            "english": "Plumber",
            "transliteration": "chang pra pa"
        },
        {
            "thai": "ช่างไม้",
            "english": "Carpenter",
            "transliteration": "chang mai"
        },
        {
            "thai": "ช่างตัดเสื้อ",
            "english": "Tailor",
            "transliteration": "chang tat suea"
        },
        {
            "thai": "นักแปล",
            "english": "Translator",
            "transliteration": "nak bplae"
        },
        {
            "thai": "นักเขียนโปรแกรม",
            "english": "Programmer",
            "transliteration": "nak khian program"
        },
        {
            "thai": "นักวิเคราะห์ข้อมูล",
            "english": "Data analyst",
            "transliteration": "nak wikroh khor mun"
        },
        {
            "thai": "ผู้จัดการผลิตภัณฑ์",
            "english": "Product manager",
            "transliteration": "phu jad gan pha lit tha phan"
        },
        {
            "thai": "การตลาด",
            "english": "Marketing",
            "transliteration": "kan ta lat"
        },
        {
            "thai": "นักการตลาด",
            "english": "Marketer",
            "transliteration": "nak kan ta lat"
        },
        {
            "thai": "ที่ปรึกษา",
            "english": "Consultant",
            "transliteration": "thi pruek sa"
        },
        {
            "thai": "สัตวแพทย์",
            "english": "Veterinarian",
            "transliteration": "sat ta wa phaet"
        },
        {
            "thai": "เภสัชกร",
            "english": "Pharmacist",
            "transliteration": "phe sat cha kon"
        },
        {
            "thai": "นักจิตวิทยา",
            "english": "Psychologist",
            "transliteration": "nak jit tha ya"
        },
        {
            "thai": "ทันตแพทย์",
            "english": "Dentist",
            "transliteration": "than ta phaet"
        },
        {
            "thai": "นักบิน",
            "english": "Pilot",
            "transliteration": "nak bin"
        },
        {
            "thai": "พนักงานต้อนรับบนเครื่องบิน",
            "english": "Flight attendant",
            "transliteration": "pa nak ngan ton rap bon khreuang bin"
        },
        {
            "thai": "รปภ.",
            "english": "Security guard",
            "transliteration": "raw por por"
        },
        {
            "thai": "ทหาร",
            "english": "Soldier",
            "transliteration": "ta han"
        },
        {
            "thai": "นักร้องนักแต่งเพลง",
            "english": "Singer-songwriter",
            "transliteration": "nak rawng nak taeng pleung"
        }
    ],
    "places": [
        {
            "thai": "ธนาคาร",
            "english": "bank",
            "transliteration": "ta na khan"
        },
        {
            "thai": "สนามบิน",
            "english": "airport",
            "transliteration": "sa nam bin"
        },
        {
            "thai": "ตลาด",
            "english": "market",
            "transliteration": "ta lad"
        },
        {
            "thai": "โรงแรม",
            "english": "hotel",
            "transliteration": "rong raem"
        },
        {
            "thai": "ร้านตัดผม",
            "english": "barber",
            "transliteration": "ran dat phom"
        },
        {
            "thai": "ร้านอาหาร",
            "english": "restaurant",
            "transliteration": "ran ahaan"
        },
        {
            "thai": "โรงพยาบาล",
            "english": "hospital",
            "transliteration": "rong phaya ban"
        },
        {
            "thai": "โรงเรียน",
            "english": "school",
            "transliteration": "rong rian"
        },
        {
            "thai": "มหาวิทยาลัย",
            "english": "university",
            "transliteration": "ma ha wit tha ya lai"
        },
        {
            "thai": "ร้านขายยา",
            "english": "pharmacy",
            "transliteration": "ran khai ya"
        },
        {
            "thai": "ห้องสมุด",
            "english": "library",
            "transliteration": "hong sa mud"
        },
        {
            "thai": "ครัว",
            "english": "kitchen",
            "transliteration": "krua"
        },
        {
            "thai": "บ้าน",
            "english": "home / house",
            "transliteration": "ban"
        },
        {
            "thai": "ห้องน้ำ",
            "english": "bathroom",
            "transliteration": "hong nam"
        },
        {
            "thai": "ร้านกาแฟ",
            "english": "cafe",
            "transliteration": "ran ga fae"
        },
        {
            "thai": "ร้านตัดผมคุณ",
            "english": "Barber",
            "transliteration": "ran tat phom khun"
        },
        {
            "thai": "สวนสาธารณะ",
            "english": "Park",
            "transliteration": "suan sa tha ra na"
        },
        {
            "thai": "พิพิธภัณฑ์",
            "english": "Museum",
            "transliteration": "phi phit tha phan"
        },
        {
            "thai": "โรงหนัง",
            "english": "Cinema",
            "transliteration": "rong nang"
        },
        {
            "thai": "สนามกีฬา",
            "english": "Stadium",
            "transliteration": "sa nam gi la"
        },
        {
            "thai": "สำนักงาน",
            "english": "Office",
            "transliteration": "sam nak ngan"
        },
        {
            "thai": "โรงงาน",
            "english": "Factory",
            "transliteration": "rong ngan"
        },
        {
            "thai": "ร้านสะดวกซื้อ",
            "english": "Convenience store",
            "transliteration": "ran sa duak seu"
        },
        {
            "thai": "ห้างสรรพสินค้า",
            "english": "Shopping mall",
            "transliteration": "hang sap pa sin kha"
        },
        {
            "thai": "วัด",
            "english": "Temple",
            "transliteration": "wat"
        },
        {
            "thai": "โบสถ์",
            "english": "Church",
            "transliteration": "bot"
        },
        {
            "thai": "มัสยิด",
            "english": "Mosque",
            "transliteration": "mat sa yit"
        },
        {
            "thai": "ไปรษณีย์",
            "english": "Post office",
            "transliteration": "bprai sa nii"
        },
        {
            "thai": "สถานีรถไฟ",
            "english": "Train station",
            "transliteration": "sa tha nii rot fai"
        },
        {
            "thai": "สถานีขนส่ง",
            "english": "Bus station",
            "transliteration": "sa tha nii khon song"
        },
        {
            "thai": "ท่าเรือ",
            "english": "Pier",
            "transliteration": "tha ruea"
        },
        {
            "thai": "คาเฟ่",
            "english": "Cafe",
            "transliteration": "kha fe"
        },
        {
            "thai": "ร้านขนมอบ",
            "english": "Bakery",
            "transliteration": "ran kha nom op"
        },
        {
            "thai": "ฟิตเนส",
            "english": "Gym",
            "transliteration": "fit nes"
        },
        {
            "thai": "สนามเด็กเล่น",
            "english": "Playground",
            "transliteration": "sa nam dek len"
        },
        {
            "thai": "สวนสัตว์",
            "english": "Zoo",
            "transliteration": "suan sat"
        },
        {
            "thai": "[ผม/ฉัน]ไปสนามบินโดยแท็กซี่",
            "english": "I go to the airport by taxi",
            "transliteration": "chan bpai sananbim doy taxi"
        }
    ],
    "prepositions": [
        {
            "thai": "ที่",
            "english": "At",
            "transliteration": "tee"
        },
        {
            "thai": "ใน",
            "english": "In",
            "transliteration": "nai"
        },
        {
            "thai": "บน",
            "english": "On",
            "transliteration": "bon"
        },
        {
            "thai": "ถัดจาก",
            "english": "Next to",
            "transliteration": "tat jak"
        },
        {
            "thai": "ระหว่าง…และ…",
            "english": "Between…and…",
            "transliteration": "ra wang…lae…"
        },
        {
            "thai": "ใต้",
            "english": "Under / South",
            "transliteration": "dai"
        },
        {
            "thai": "กลาง",
            "english": "Middle",
            "transliteration": "glang"
        },
        {
            "thai": "ตรงกลาง",
            "english": "In the middle",
            "transliteration": "trong glang"
        },
        {
            "thai": "ข้างหลัง",
            "english": "Behind",
            "transliteration": "khâang lǎng"
        },
        {
            "thai": "ข้างหน้า",
            "english": "In front of",
            "transliteration": "khâang nâa"
        },
        {
            "thai": "มุม",
            "english": "Corner",
            "transliteration": "moum"
        },
        {
            "thai": "ตรงข้าม",
            "english": "Opposite",
            "transliteration": "trong khâam"
        },
        {
            "thai": "ตรงข้ามกัน",
            "english": "Opposite (each other)",
            "transliteration": "trong khâam gan"
        },
        {
            "thai": "ติดกับ",
            "english": "Attached to",
            "transliteration": "tìt gàp"
        },
        {
            "thai": "หันหน้าชนกับ",
            "english": "Facing",
            "transliteration": "hǎn nâa chon gàp"
        },
        {
            "thai": "ขนาน",
            "english": "Parallel",
            "transliteration": "kha-nǎan"
        },
        {
            "thai": "ด้านยาวของ",
            "english": "Long side of",
            "transliteration": "dâan yaao khɔ̌ɔng"
        }
    ],
    "pronouns": [
        {
            "thai": "[ผม/ฉัน]",
            "english": "I (neutral)",
            "transliteration": "chan"
        },
        {
            "thai": "ผม",
            "english": "I (male)",
            "transliteration": "phom"
        },
        {
            "thai": "ดิ[ผม/ฉัน]",
            "english": "I (female formal)",
            "transliteration": "di-chan"
        },
        {
            "thai": "คุณ",
            "english": "you",
            "transliteration": "khun"
        },
        {
            "thai": "เขา",
            "english": "he / she / they (singular)",
            "transliteration": "khao"
        },
        {
            "thai": "พวกเรา",
            "english": "we",
            "transliteration": "puak rao"
        },
        {
            "thai": "พวกเขา",
            "english": "they",
            "transliteration": "puak khao"
        },
        {
            "thai": "ตัว[ผม/ฉัน]เอง",
            "english": "myself",
            "transliteration": "tua chan eng"
        },
        {
            "thai": "[ผม/ฉัน]นอนหลับตอนสองทุ่ม",
            "english": "I sleep at 10 pm",
            "transliteration": "chan nawnlap ton song thum"
        },
        {
            "thai": "ขอให้สนุก",
            "english": "Wish you fun",
            "transliteration": "kaw hai sanuk"
        },
        {
            "thai": "ขอให้หายเร็ว ๆ",
            "english": "Hope you will get better soon",
            "transliteration": "kaw hai kay"
        },
        {
            "thai": "ปวดหัว",
            "english": "Headache",
            "transliteration": "puathua"
        }
    ],
    "question_words": [
        {
            "thai": "เมื่อไหร่",
            "english": "when",
            "transliteration": "meu rai"
        },
        {
            "thai": "ที่ไหน",
            "english": "where",
            "transliteration": "tee nai"
        },
        {
            "thai": "ทำไม",
            "english": "why",
            "transliteration": "tum mai"
        },
        {
            "thai": "อย่างไร",
            "english": "how",
            "transliteration": "yang rai"
        },
        {
            "thai": "อะไร",
            "english": "what",
            "transliteration": "a rai"
        },
        {
            "thai": "ใคร",
            "english": "who",
            "transliteration": "krai"
        },
        {
            "thai": "เท่าไหร่",
            "english": "how much / how many",
            "transliteration": "tao rai"
        },
        {
            "thai": "กี่โมง",
            "english": "what time",
            "transliteration": "gee mong"
        },
        {
            "thai": "อันไหน",
            "english": "which (thing)",
            "transliteration": "an nai"
        },
        {
            "thai": "กี่ + classifier",
            "english": "How many",
            "transliteration": "gee + classifier"
        },
        {
            "thai": "นานแค่ไหน",
            "english": "How long (time)",
            "transliteration": "nan khae nai"
        },
        {
            "thai": "ไกลแค่ไหน",
            "english": "How far",
            "transliteration": "glai khae nai"
        },
        {
            "thai": "บ่อยแค่ไหน",
            "english": "How often",
            "transliteration": "boy khae nai"
        },
        {
            "thai": "ยังไง",
            "english": "how",
            "transliteration": "yang ngai"
        },
        {
            "thai": "ขอ",
            "english": "Can I have ?",
            "transliteration": "kaw"
        },
        {
            "thai": "เป็นอะไร",
            "english": "What is it ?",
            "transliteration": "bpen a rai"
        }
    ],
    "rooms_and_house": [
        {
            "thai": "ห้อง",
            "english": "Room",
            "transliteration": "hɔ̂ng"
        },
        {
            "thai": "ห้องนั่งเล่น",
            "english": "Living room",
            "transliteration": "hɔ̂ng nâng-lên"
        },
        {
            "thai": "ประตู",
            "english": "Door",
            "transliteration": "bprà-dtuu"
        },
        {
            "thai": "หน้าต่าง",
            "english": "Window",
            "transliteration": "nâa-dtàang"
        },
        {
            "thai": "บาน",
            "english": "Classifier",
            "transliteration": "baan"
        },
        {
            "thai": "ผนัง",
            "english": "Wall (surface)",
            "transliteration": "phà-nǎng"
        },
        {
            "thai": "กำแพง",
            "english": "Wall (structure)",
            "transliteration": "gam-phɛɛng"
        }
    ],
    "sample_questions_answers": [
        {
            "thai": "คุณทำงานที่ไหน",
            "english": "Where do you work?",
            "transliteration": "khun tum ngan tee nai"
        },
        {
            "thai": "[ผม/ฉัน]ทำงานที่โรงแรม",
            "english": "I work at a hotel",
            "transliteration": "chan tum ngan tee rong raem"
        },
        {
            "thai": "คุณอยู่ที่ไหน",
            "english": "Where do you live?",
            "transliteration": "khun yoo tee nai"
        },
        {
            "thai": "[ผม/ฉัน]อยู่ที่กรุงเทพ",
            "english": "I live in Bangkok",
            "transliteration": "chan yoo tee krung thep"
        },
        {
            "thai": "คุณเรียนที่ไหน",
            "english": "Where do you study?",
            "transliteration": "khun rian tee nai"
        },
        {
            "thai": "[ผม/ฉัน]เรียนที่มหาวิทยาลัย",
            "english": "I study at a university",
            "transliteration": "chan rian tee ma ha wit tha ya lai"
        },
        {
            "thai": "คุณชอบกินอะไร",
            "english": "What do you like to eat?",
            "transliteration": "khun chop gin a rai"
        },
        {
            "thai": "[ผม/ฉัน]ชอบกินอาหารไทย",
            "english": "I like to eat Thai food",
            "transliteration": "chan chop gin ahaan thai"
        },
        {
            "thai": "คุณชอบดื่มอะไร",
            "english": "What do you like to drink?",
            "transliteration": "khun chop deum a rai"
        },
        {
            "thai": "[ผม/ฉัน]ชอบดื่มกาแฟ",
            "english": "I like to drink coffee",
            "transliteration": "chan chop deum kafae"
        },
        {
            "thai": "คุณชอบดูอะไร",
            "english": "What do you like to watch?",
            "transliteration": "khun chop doo a rai"
        },
        {
            "thai": "[ผม/ฉัน]ชอบดูหนัง",
            "english": "I like to watch movies",
            "transliteration": "chan chop doo nang"
        },
        {
            "thai": "คุณชอบฟังอะไร",
            "english": "What do you like to listen to?",
            "transliteration": "khun chop fang a rai"
        },
        {
            "thai": "[ผม/ฉัน]ชอบฟังเพลง",
            "english": "I like to listen to music",
            "transliteration": "chan chop fang pleng"
        },
        {
            "thai": "ทำไมคุณอยู่ที่กรุงเทพ",
            "english": "Why do you live in Bangkok?",
            "transliteration": "tum mai khun yoo tee krung thep"
        },
        {
            "thai": "[ผม/ฉัน]อยู่ที่กรุงเทพเพราะ[ผม/ฉัน]ทำงานที่นี่",
            "english": "I live in Bangkok because I work here",
            "transliteration": "chan yoo tee krung thep pror chan tum ngan tee nee"
        },
        {
            "thai": "ทำไมคุณเรียนภาษาไทย",
            "english": "Why do you study Thai language?",
            "transliteration": "tum mai khun rian pasa thai"
        },
        {
            "thai": "[ผม/ฉัน]เรียนภาษาไทยเพราะ[ผม/ฉัน]ชอบวัฒนธรรมไทย",
            "english": "I study Thai because I like Thai culture",
            "transliteration": "chan rian pasa thai pror chan chop wat tha na tham"
        },
        {
            "thai": "คุณไปทำงานอย่างไร",
            "english": "How do you go to work?",
            "transliteration": "khun bpai tum ngan yang rai"
        },
        {
            "thai": "[ผม/ฉัน]ไปทำงานโดยรถไฟฟ้า",
            "english": "I go to work by BTS",
            "transliteration": "chan bpai tum ngan doy rot fai fa"
        },
        {
            "thai": "คุณไปตลาดอย่างไร",
            "english": "How do you go to the market?",
            "transliteration": "khun bpai ta lad yang rai"
        },
        {
            "thai": "[ผม/ฉัน]ไปตลาดโดยมอเตอร์ไซค์",
            "english": "I go to the market by motorbike",
            "transliteration": "chan bpai ta lad doy motor sai"
        },
        {
            "thai": "คุณไปธนาคารอย่างไร",
            "english": "How do you go to the bank?",
            "transliteration": "khun bpai ta na khan yang rai"
        },
        {
            "thai": "[ผม/ฉัน]ไปธนาคารโดยรถยนต์",
            "english": "I go to the bank by car",
            "transliteration": "chan bpai ta na khan doy rot yon"
        },
        {
            "thai": "คุณไปร้านขายยาอย่างไร",
            "english": "How do you go to the pharmacy?",
            "transliteration": "khun bpai ran khai ya yang rai"
        },
        {
            "thai": "[ผม/ฉัน]ไปร้านขายยาโดยเดิน",
            "english": "I go to the pharmacy by foot",
            "transliteration": "chan bpai ran khai ya doy dern"
        },
        {
            "thai": "คุณนอนหลับเมื่อไหร่",
            "english": "When do you sleep?",
            "transliteration": "khun nawn lap meu rai"
        },
        {
            "thai": "[ผม/ฉัน]นอนหลับตอนสามทุ่ม",
            "english": "I sleep at 9 pm",
            "transliteration": "chan nawn lap ton sam thum"
        },
        {
            "thai": "คุณอ่านหนังสือเมื่อไหร่",
            "english": "When do you read books?",
            "transliteration": "khun an nangsue meu rai"
        },
        {
            "thai": "[ผม/ฉัน]อ่านหนังสือในตอนเย็น",
            "english": "I read books in the evening",
            "transliteration": "chan an nangsue nai ton yen"
        },
        {
            "thai": "คุณเขียนเมื่อไหร่",
            "english": "When do you write?",
            "transliteration": "khun kian meu rai"
        },
        {
            "thai": "[ผม/ฉัน]เขียนในตอนเช้า",
            "english": "I write in the morning",
            "transliteration": "chan kian nai ton chao"
        },
        {
            "thai": "คุณเรียนเมื่อไหร่",
            "english": "When do you study?",
            "transliteration": "khun rian meu rai"
        },
        {
            "thai": "[ผม/ฉัน]เรียนในตอนบ่าย",
            "english": "I study in the afternoon",
            "transliteration": "chan rian nai ton bai"
        },
        {
            "thai": "คุณทำงานเมื่อไหร่",
            "english": "When do you work?",
            "transliteration": "khun tum ngan meu rai"
        },
        {
            "thai": "[ผม/ฉัน]ทำงานในตอนกลางวัน",
            "english": "I work during the day",
            "transliteration": "chan tum ngan nai ton klang wan"
        },
        {
            "thai": "เมื่อไหร่, เมื่อไร",
            "english": "when",
            "transliteration": "meu rai"
        },
        {
            "thai": "เขาไปทำงานอย่างไร",
            "english": "How does he go to work?",
            "transliteration": "khao bpai tum ngan yang rai"
        },
        {
            "thai": "คุณไปสนามบินอย่างไร",
            "english": "How do you go to the airport?",
            "transliteration": "khun bpai sananbim yang rai"
        },
        {
            "thai": "สบายดีมั้ย, เป็นยังไงบ้าง",
            "english": "How are you doing ?",
            "transliteration": "sa bai di mai, pen yang nai ban"
        },
        {
            "thai": "เกิดอะไร(ขึ้น)",
            "english": "what happened ?",
            "transliteration": ""
        }
    ],
    "time_and_day": [
        {
            "thai": "ตอนเช้า",
            "english": "morning",
            "transliteration": "ton chao"
        },
        {
            "thai": "ตอนบ่าย",
            "english": "afternoon",
            "transliteration": "ton bai"
        },
        {
            "thai": "ตอนเย็น",
            "english": "evening",
            "transliteration": "ton yen"
        },
        {
            "thai": "กลางคืน",
            "english": "night",
            "transliteration": "klang kheun"
        },
        {
            "thai": "วันนี้",
            "english": "today",
            "transliteration": "wan nee"
        },
        {
            "thai": "เมื่อวาน",
            "english": "yesterday",
            "transliteration": "meua wan"
        },
        {
            "thai": "พรุ่งนี้",
            "english": "tomorrow",
            "transliteration": "proong nee"
        },
        {
            "thai": "วันจันทร์",
            "english": "Monday",
            "transliteration": "wan jan"
        },
        {
            "thai": "วันอังคาร",
            "english": "Tuesday",
            "transliteration": "wan ang karn"
        },
        {
            "thai": "วันพุธ",
            "english": "Wednesday",
            "transliteration": "wan phoot"
        },
        {
            "thai": "วันพฤหัสบดี",
            "english": "Thursday",
            "transliteration": "wan pa rue hat sa bo dee"
        },
        {
            "thai": "วันศุกร์",
            "english": "Friday",
            "transliteration": "wan sook"
        },
        {
            "thai": "วันเสาร์",
            "english": "Saturday",
            "transliteration": "wan sao"
        },
        {
            "thai": "วันอาทิตย์",
            "english": "Sunday",
            "transliteration": "wan aa thit"
        },
        {
            "thai": "กี่โมง",
            "english": "what time",
            "transliteration": "gee mong"
        },
        {
            "thai": "ชั่วโมง",
            "english": "Hour",
            "transliteration": "chûa-mong"
        },
        {
            "thai": "อาทิตย์",
            "english": "Week (spoken)",
            "transliteration": "aa-thít"
        },
        {
            "thai": "สัปดาห์",
            "english": "Week (official)",
            "transliteration": "sàp-daa"
        },
        {
            "thai": "ทุก",
            "english": "Every",
            "transliteration": "thúk"
        },
        {
            "thai": "เวลา",
            "english": "time",
            "transliteration": "wela"
        },
        {
            "thai": "เวลาว่าง",
            "english": "free time",
            "transliteration": "wela wang"
        }
    ],
    "transportation": [
        {
            "thai": "รถไฟฟ้า",
            "english": "BTS / skytrain",
            "transliteration": "rot fai fa"
        },
        {
            "thai": "รถยนต์",
            "english": "car",
            "transliteration": "rot yon"
        },
        {
            "thai": "มอเตอร์ไซค์",
            "english": "motorcycle",
            "transliteration": "motor sai"
        },
        {
            "thai": "แท็กซี่",
            "english": "taxi",
            "transliteration": "taxi"
        },
        {
            "thai": "จักรยาน",
            "english": "bicycle",
            "transliteration": "jak ra yan"
        },
        {
            "thai": "รถเมล์",
            "english": "bus",
            "transliteration": "rot mae"
        },
        {
            "thai": "เรือ",
            "english": "boat",
            "transliteration": "ruea"
        },
        {
            "thai": "เครื่องบิน",
            "english": "airplane",
            "transliteration": "kreuang bin"
        },
        {
            "thai": "รถไฟ",
            "english": "train",
            "transliteration": "rot fai"
        },
        {
            "thai": "ขับรถดี ๆ, ขี่รถดี ๆ",
            "english": "Drive carefully, ride carefully",
            "transliteration": "kap rot dee dee"
        }
    ],
    "useful_expressions": [
        {
            "thai": "พูดอีกครั้ง",
            "english": "Say it again",
            "transliteration": "pood eek krang"
        }
    ],
    "verb_to_be_in_thai": [
        {
            "thai": "มันคือโรงเรียน",
            "english": "It is a school.",
            "transliteration": "man kue rong rian"
        },
        {
            "thai": "มันอยู่ที่โรงเรียน",
            "english": "It is at school.",
            "transliteration": "man yoo tee rong rian"
        }
    ],
    "verbs_actions": [
        {
            "thai": "นอนหลับ",
            "english": "sleep",
            "transliteration": "nawn lap"
        },
        {
            "thai": "ตื่น",
            "english": "wake up",
            "transliteration": "tuen"
        },
        {
            "thai": "เปิด",
            "english": "open",
            "transliteration": "bpert"
        },
        {
            "thai": "ปิด",
            "english": "close",
            "transliteration": "bpid"
        },
        {
            "thai": "อ่าน",
            "english": "read",
            "transliteration": "an"
        },
        {
            "thai": "เขียน",
            "english": "write",
            "transliteration": "kian"
        },
        {
            "thai": "พูด",
            "english": "speak",
            "transliteration": "pood"
        },
        {
            "thai": "ฟัง",
            "english": "listen",
            "transliteration": "fang"
        },
        {
            "thai": "ดู",
            "english": "watch / look",
            "transliteration": "doo"
        },
        {
            "thai": "เรียน",
            "english": "study",
            "transliteration": "rian"
        },
        {
            "thai": "ทำงาน",
            "english": "work",
            "transliteration": "tum ngan"
        },
        {
            "thai": "ไป",
            "english": "go",
            "transliteration": "bpai"
        },
        {
            "thai": "มา",
            "english": "come",
            "transliteration": "ma"
        },
        {
            "thai": "กิน",
            "english": "eat",
            "transliteration": "gin"
        },
        {
            "thai": "ดื่ม",
            "english": "drink",
            "transliteration": "deum"
        },
        {
            "thai": "ซื้อ",
            "english": "buy",
            "transliteration": "seu"
        },
        {
            "thai": "ขาย",
            "english": "sell",
            "transliteration": "khai"
        },
        {
            "thai": "เดิน",
            "english": "walk",
            "transliteration": "dern"
        },
        {
            "thai": "วิ่ง",
            "english": "run",
            "transliteration": "wing"
        },
        {
            "thai": "ขับรถ",
            "english": "drive",
            "transliteration": "kab rot"
        },
        {
            "thai": "นั่ง",
            "english": "sit",
            "transliteration": "nang"
        },
        {
            "thai": "ยืน",
            "english": "stand",
            "transliteration": "yeun"
        },
        {
            "thai": "คิด",
            "english": "think",
            "transliteration": "kid"
        },
        {
            "thai": "รอ",
            "english": "wait",
            "transliteration": "ror"
        },
        {
            "thai": "ชอบ",
            "english": "like",
            "transliteration": "chop"
        },
        {
            "thai": "รัก",
            "english": "love",
            "transliteration": "rak"
        },
        {
            "thai": "เห็น",
            "english": "see",
            "transliteration": "hen"
        },
        {
            "thai": "ได้ยิน",
            "english": "hear",
            "transliteration": "dai yin"
        },
        {
            "thai": "เข้า",
            "english": "enter",
            "transliteration": "khao"
        },
        {
            "thai": "ออก",
            "english": "exit / go out",
            "transliteration": "awk"
        },
        {
            "thai": "ทำอาหาร",
            "english": "Cook",
            "transliteration": "tam ahaan"
        },
        {
            "thai": "มาถึง",
            "english": "Arrive",
            "transliteration": "ma theung"
        },
        {
            "thai": "ออกไป",
            "english": "Leave",
            "transliteration": "awk bpai"
        },
        {
            "thai": "นอน",
            "english": "Lie down",
            "transliteration": "nawn"
        },
        {
            "thai": "รู้",
            "english": "Know",
            "transliteration": "ruu"
        },
        {
            "thai": "เข้าใจ",
            "english": "Understand",
            "transliteration": "khao jai"
        },
        {
            "thai": "อยาก",
            "english": "Want",
            "transliteration": "yaak"
        },
        {
            "thai": "ต้องการ",
            "english": "Need",
            "transliteration": "dtawng gan"
        },
        {
            "thai": "มี",
            "english": "Have",
            "transliteration": "mee"
        },
        {
            "thai": "ได้",
            "english": "Get",
            "transliteration": "dai"
        },
        {
            "thai": "ให้",
            "english": "Give",
            "transliteration": "hai"
        },
        {
            "thai": "เอา",
            "english": "Take",
            "transliteration": "ao"
        },
        {
            "thai": "ใช้",
            "english": "Use",
            "transliteration": "chai"
        },
        {
            "thai": "ทำ",
            "english": "Make",
            "transliteration": "tam"
        },
        {
            "thai": "พยายาม",
            "english": "Try",
            "transliteration": "pa ya yaam"
        },
        {
            "thai": "เริ่ม",
            "english": "Start",
            "transliteration": "ruem"
        },
        {
            "thai": "เสร็จ",
            "english": "Finish",
            "transliteration": "set"
        },
        {
            "thai": "โทร",
            "english": "Call (phone)",
            "transliteration": "toh"
        },
        {
            "thai": "จ่าย",
            "english": "Pay",
            "transliteration": "jai"
        },
        {
            "thai": "ช่วย",
            "english": "Help",
            "transliteration": "chuay"
        },
        {
            "thai": "ถาม",
            "english": "Ask",
            "transliteration": "taam"
        },
        {
            "thai": "ตอบ",
            "english": "Answer",
            "transliteration": "dtawp"
        },
        {
            "thai": "จำ",
            "english": "Remember",
            "transliteration": "jam"
        },
        {
            "thai": "ลืม",
            "english": "Forget",
            "transliteration": "leum"
        },
        {
            "thai": "เจอ",
            "english": "Meet",
            "transliteration": "jer"
        },
        {
            "thai": "เยี่ยม",
            "english": "Visit",
            "transliteration": "yiam"
        },
        {
            "thai": "อาศัย",
            "english": "Live (reside)",
            "transliteration": "a sai"
        },
        {
            "thai": "พัก",
            "english": "Stay",
            "transliteration": "pak"
        },
        {
            "thai": "สอน",
            "english": "Teach",
            "transliteration": "sawn"
        },
        {
            "thai": "เรียนรู้",
            "english": "Learn",
            "transliteration": "rian ruu"
        },
        {
            "thai": "ฝึก",
            "english": "Practice",
            "transliteration": "feuk"
        },
        {
            "thai": "ออกกำลังกาย",
            "english": "Exercise",
            "transliteration": "awk gam lang gai"
        },
        {
            "thai": "ล้าง",
            "english": "Wash",
            "transliteration": "lang"
        },
        {
            "thai": "ทำความสะอาด",
            "english": "Clean",
            "transliteration": "tam khwam sa-at"
        },
        {
            "thai": "เปลือก",
            "english": "peel",
            "transliteration": "plueak"
        },
        {
            "thai": "ขอให้",
            "english": "wish",
            "transliteration": "kaw hai"
        },
        {
            "thai": "ขอให้อร่อย",
            "english": "Bon appetit",
            "transliteration": "kaw hai a roi"
        },
        {
            "thai": "เจ็บ",
            "english": "pain",
            "transliteration": "jep"
        },
        {
            "thai": "ปัญหา",
            "english": "problem",
            "transliteration": "panha"
        },
        {
            "thai": "ไม่สบาย",
            "english": "sick",
            "transliteration": "mai sa bai"
        },
        {
            "thai": "หรือยัง / รึยัง",
            "english": "yet",
            "transliteration": "ru yang"
        },
        {
            "thai": "แล้ว",
            "english": "already",
            "transliteration": "leow"
        },
        {
            "thai": "แต่งงาน",
            "english": "to marry",
            "transliteration": "tang gnang"
        },
        {
            "thai": "ว่าง",
            "english": "free",
            "transliteration": "wang"
        }
    ]
};
// Global variables
let currentSection = 'greetings_and_basic_expressions';
let viewMode = 'grid';
let searchQuery = '';
let cardStates = {}; // Store current slide index for each card
let languageOrder = ['thai', 'transliteration', 'english']; // Default order

// Premium functionality
function togglePremium() {
    const body = document.body;
    const premiumBtn = document.getElementById('premiumBtn');
    const isPremium = body.classList.contains('premium-active');
    
    if (isPremium) {
        // Deactivate premium
        body.classList.remove('premium-active');
        premiumBtn.innerHTML = '<span class="premium-icon">👑</span><span class="premium-text">Go Premium</span>';
        premiumBtn.classList.remove('active');
        localStorage.setItem('thaiPremiumStatus', 'false');
        
        // Show success message
        showNotification('Premium deactivated. Ads are now visible.', 'info');
    } else {
        // Activate premium
        body.classList.add('premium-active');
        premiumBtn.innerHTML = '<span class="premium-icon">✅</span><span class="premium-text">Premium Active</span>';
        premiumBtn.classList.add('active');
        localStorage.setItem('thaiPremiumStatus', 'true');
        
        // Show success message
        showNotification('🎉 Premium activated! Ads removed for better learning experience.', 'success');
    }
}

function loadPremiumStatus() {
    const isPremium = localStorage.getItem('thaiPremiumStatus') === 'true';
    if (isPremium) {
        document.body.classList.add('premium-active');
        const premiumBtn = document.getElementById('premiumBtn');
        if (premiumBtn) {
            premiumBtn.innerHTML = '<span class="premium-icon">✅</span><span class="premium-text">Premium Active</span>';
            premiumBtn.classList.add('active');
        }
    }
}

function showNotification(message, type = 'info') {
    // Remove existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Sticky search functionality
function setupStickySearch() {
    const stickySearch = document.getElementById('stickySearch');
    const topControls = document.querySelector('.top-controls');
    let isSticky = false;
    
    function checkStickySearch() {
        const topControlsRect = topControls.getBoundingClientRect();
        const shouldBeSticky = topControlsRect.bottom < 0;
        
        if (shouldBeSticky && !isSticky) {
            // Show sticky search
            stickySearch.classList.add('visible');
            document.body.classList.add('sticky-search-active');
            isSticky = true;
        } else if (!shouldBeSticky && isSticky) {
            // Hide sticky search
            stickySearch.classList.remove('visible');
            document.body.classList.remove('sticky-search-active');
            isSticky = false;
        }
    }
    
    // Check on scroll
    window.addEventListener('scroll', checkStickySearch);
    
    // Check on resize
    window.addEventListener('resize', checkStickySearch);
    
    // Initial check
    checkStickySearch();
}

// Scroll to search results when filtering
function scrollToSearchResults() {
    if (searchQuery) {
        // Find the first visible section with results
        const visibleSection = document.querySelector('.section.active');
        if (visibleSection) {
            const stickyHeight = document.querySelector('.sticky-search.visible') ? 70 : 0;
            const targetY = visibleSection.offsetTop - stickyHeight - 20;
            
            window.scrollTo({
                top: Math.max(0, targetY),
                behavior: 'smooth'
            });
        }
    }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    loadSavedLanguageOrder();
    loadPremiumStatus();
    initializeApp();
});

function loadSavedLanguageOrder() {
    const saved = localStorage.getItem('thaiLanguageOrder');
    if (saved) {
        try {
            languageOrder = JSON.parse(saved);
        } catch (e) {
            // If parsing fails, keep default order
            console.warn('Failed to load saved language order, using default');
        }
    }
}

// Helper function for flexible word matching
function matchesWordBoundary(text, searchTerm) {
    const lowerText = text.toLowerCase();
    const lowerTerm = searchTerm.toLowerCase();
    
    // For Thai text, use simple contains since Thai doesn't use spaces between words
    if (/[\u0E00-\u0E7F]/.test(text)) {
        return lowerText.includes(lowerTerm);
    }
    
    // For English/transliteration: match if the search term appears anywhere in the text
    // This allows "train" to match "train", "train station", "skytrain", etc.
    return lowerText.includes(lowerTerm);
}

// Multi-term search function
function matchesSearchQuery(item, query) {
    if (!query) return true;
    
    // Split by comma and trim whitespace from each term
    const searchTerms = query.split(',').map(term => term.trim()).filter(term => term.length > 0);
    
    if (searchTerms.length === 0) return true;
    
    // If there's only one term (no comma), search normally
    if (searchTerms.length === 1) {
        const term = searchTerms[0];
        return matchesWordBoundary(item.thai, term) ||
               matchesWordBoundary(item.english, term) ||
               matchesWordBoundary(item.transliteration, term);
    }
    
    // For multiple terms, check if ANY search term matches (OR logic)
    // This is more user-friendly than AND logic
    return searchTerms.some(term => {
        return matchesWordBoundary(item.thai, term) ||
               matchesWordBoundary(item.english, term) ||
               matchesWordBoundary(item.transliteration, term);
    });
}

function initializeApp() {
    createNavigation();
    createGlobalLanguageOrderSelector();
    createSections();
    setupEventListeners();
    showSection(currentSection);
    initializeCardStates();
}

function createNavigation() {
    const select = document.getElementById('categorySelect');
    const sections = Object.keys(yamlData).filter(key => key !== 'metadata');
    
    sections.forEach(section => {
        const option = document.createElement('option');
        option.value = section;
        option.textContent = formatSectionTitle(section);
        
        if (section === currentSection) {
            option.selected = true;
        }
        
        select.appendChild(option);
    });
    
    // Add change event listener
    select.addEventListener('change', function() {
        if (this.value !== 'search_results') {
            // Clear search when selecting a specific category
            document.getElementById('searchInput').value = '';
            searchQuery = '';
            showSection(this.value);
        }
    });
}

function formatSectionTitle(sectionKey) {
    return sectionKey
        .replace(/_/g, ' ')
        .replace(/\b\w/g, l => l.toUpperCase());
}

function createSections() {
    const content = document.getElementById('content');
    const sections = Object.keys(yamlData).filter(key => key !== 'metadata');
    
    sections.forEach(sectionKey => {
        const section = document.createElement('div');
        section.className = 'section';
        section.id = sectionKey;
        
        const title = document.createElement('h2');
        title.className = 'section-title';
        title.textContent = formatSectionTitle(sectionKey);
        
        const cardsContainer = document.createElement('div');
        cardsContainer.className = 'cards-grid';
        cardsContainer.id = `cards-${sectionKey}`;
        
        section.appendChild(title);
        section.appendChild(cardsContainer);
        content.appendChild(section);
        
        createCards(sectionKey, yamlData[sectionKey]);
    });
}

function createCards(sectionKey, items) {
    const container = document.getElementById(`cards-${sectionKey}`);
    
    items.forEach((item, index) => {
        const card = createCard(item, `${sectionKey}-${index}`);
        container.appendChild(card);
    });
}

function createCard(item, cardId) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.cardId = cardId;
    
    // Initialize card state
    cardStates[cardId] = 0;
    
    const content = document.createElement('div');
    content.className = 'card-content';
    
    // Language content for grid view (single language display)
    const languageContent = document.createElement('div');
    languageContent.className = 'language-content';
    
    const languageLabel = document.createElement('div');
    languageLabel.className = 'language-label';
    
    const languageText = document.createElement('div');
    languageText.className = 'language-text';
    
    // All languages content for list view (all languages side by side)
    const allLanguagesContent = document.createElement('div');
    allLanguagesContent.className = 'all-languages';
    allLanguagesContent.style.display = 'none';
    
    // English
    const englishItem = document.createElement('div');
    englishItem.className = 'language-item';
    englishItem.innerHTML = `
        <div class="language-label">English</div>
        <div class="language-text english-text">${item.english}</div>
    `;
    
    // Transliteration
    const transliterationItem = document.createElement('div');
    transliterationItem.className = 'language-item';
    transliterationItem.innerHTML = `
        <div class="language-label">Pronunciation</div>
        <div class="language-text transliteration-text">${item.transliteration}</div>
    `;
    
    // Thai
    const thaiItem = document.createElement('div');
    thaiItem.className = 'language-item';
    thaiItem.innerHTML = `
        <div class="language-label">Thai</div>
        <div class="language-text thai-text">${item.thai}</div>
    `;
    
    allLanguagesContent.appendChild(englishItem);
    allLanguagesContent.appendChild(transliterationItem);
    allLanguagesContent.appendChild(thaiItem);
    
    // Slider controls (only for grid view)
    const sliderControls = document.createElement('div');
    sliderControls.className = 'slider-controls';
    
    const prevBtn = document.createElement('button');
    prevBtn.className = 'slider-btn';
    prevBtn.innerHTML = '‹';
    prevBtn.onclick = (e) => {
        e.stopPropagation();
        changeSlide(cardId, -1);
    };
    
    const nextBtn = document.createElement('button');
    nextBtn.className = 'slider-btn';
    nextBtn.innerHTML = '›';
    nextBtn.onclick = (e) => {
        e.stopPropagation();
        changeSlide(cardId, 1);
    };
    
    const indicators = document.createElement('div');
    indicators.className = 'slider-indicators';
    
    // Create indicators
    for (let i = 0; i < 3; i++) {
        const indicator = document.createElement('div');
        indicator.className = 'indicator';
        if (i === 0) indicator.classList.add('active');
        indicator.onclick = (e) => {
            e.stopPropagation();
            setSlide(cardId, i);
        };
        indicators.appendChild(indicator);
    }
    
    sliderControls.appendChild(prevBtn);
    sliderControls.appendChild(indicators);
    sliderControls.appendChild(nextBtn);
    
    // Google Translate link
    const translateLink = document.createElement('a');
    translateLink.className = 'translate-link';
    translateLink.href = `https://translate.google.com/?sl=th&tl=en&text=${encodeURIComponent(item.thai)}&op=translate`;
    translateLink.target = '_blank';
    translateLink.rel = 'noopener noreferrer';
    translateLink.innerHTML = '🔊 Google Translate';
    translateLink.onclick = (e) => e.stopPropagation();
    
    languageContent.appendChild(languageLabel);
    languageContent.appendChild(languageText);
    
    content.appendChild(languageContent);
    content.appendChild(allLanguagesContent);
    content.appendChild(sliderControls);
    content.appendChild(translateLink);
    
    card.appendChild(content);
    
    // Store item data
    card.dataset.item = JSON.stringify(item);
    
    // Update card display
    updateCardDisplay(card, item, 0);
    
    // Add click handler for card flip (only in grid view)
    card.onclick = () => {
        if (!card.classList.contains('list-view')) {
            changeSlide(cardId, 1);
        }
    };
    
    return card;
}

function updateCardDisplay(card, item, slideIndex) {
    const languageLabel = card.querySelector('.language-label');
    const languageText = card.querySelector('.language-text');
    const indicators = card.querySelectorAll('.indicator');
    const prevBtn = card.querySelector('.slider-btn:first-child');
    const nextBtn = card.querySelector('.slider-btn:last-child');
    
    // Use global language order
    const currentOrder = languageOrder;
    
    // Update indicators
    indicators.forEach((indicator, index) => {
        indicator.classList.toggle('active', index === slideIndex);
    });
    
    // Update indicator colors based on order
    updateIndicatorsOrder(card, currentOrder);
    
    // Buttons are never disabled in circular mode
    if (prevBtn) prevBtn.disabled = false;
    if (nextBtn) nextBtn.disabled = false;
    
    // Update content based on global order
    const currentLang = currentOrder[slideIndex];
    const langConfig = {
        'thai': {
            label: 'Thai',
            text: item.thai,
            className: 'language-text thai-text'
        },
        'english': {
            label: 'English',
            text: item.english,
            className: 'language-text english-text'
        },
        'transliteration': {
            label: 'Pronunciation',
            text: item.transliteration,
            className: 'language-text transliteration-text'
        }
    };
    
    if (langConfig[currentLang]) {
        languageLabel.textContent = langConfig[currentLang].label;
        languageText.textContent = langConfig[currentLang].text;
        languageText.className = langConfig[currentLang].className;
    }
}

function changeSlide(cardId, direction) {
    const currentSlide = cardStates[cardId];
    let newSlide = currentSlide + direction;
    
    // Make it circular - wrap around at the ends
    if (newSlide > 2) {
        newSlide = 0; // Go from last slide to first
    } else if (newSlide < 0) {
        newSlide = 2; // Go from first slide to last
    }
    
    setSlide(cardId, newSlide);
}

function setSlide(cardId, slideIndex) {
    cardStates[cardId] = slideIndex;
    const card = document.querySelector(`[data-card-id="${cardId}"]`);
    const item = JSON.parse(card.dataset.item);
    updateCardDisplay(card, item, slideIndex);
}

function initializeCardStates() {
    document.querySelectorAll('.card').forEach(card => {
        const cardId = card.dataset.cardId;
        if (cardStates[cardId] === undefined) {
            cardStates[cardId] = 0;
        }
    });
}

function setupEventListeners() {
    // View mode toggle
    document.querySelectorAll('input[name="viewMode"]').forEach(radio => {
        radio.addEventListener('change', function() {
            viewMode = this.value;
            updateViewMode();
        });
    });
    
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const stickySearchInput = document.getElementById('stickySearchInput');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    
    // Sync both search inputs
    function updateSearch(value) {
        searchQuery = value.toLowerCase().trim();
        searchInput.value = value;
        stickySearchInput.value = value;
        filterCards();
    }
    
    searchInput.addEventListener('input', function() {
        updateSearch(this.value);
    });
    
    stickySearchInput.addEventListener('input', function() {
        updateSearch(this.value);
    });
    
    clearSearchBtn.addEventListener('click', function() {
        updateSearch('');
        stickySearchInput.focus();
    });
    
    // Sticky search bar functionality
    setupStickySearch();
    
    // Premium button functionality
    const premiumBtn = document.getElementById('premiumBtn');
    premiumBtn.addEventListener('click', function() {
        togglePremium();
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowRight') {
            navigateSection(1);
        } else if (e.key === 'ArrowLeft') {
            navigateSection(-1);
        } else if (e.key === 'Escape') {
            document.getElementById('searchInput').value = '';
            searchQuery = '';
            filterCards();
        }
    });
}

function showSection(sectionKey) {
    // Don't change section if it's search results
    if (sectionKey === 'search_results') {
        return;
    }
    
    currentSection = sectionKey;
    
    // Update select dropdown
    const select = document.getElementById('categorySelect');
    select.value = sectionKey;
    
    // Remove search results option if it exists
    const searchOption = select.querySelector('option[value="search_results"]');
    if (searchOption) {
        searchOption.remove();
    }
    
    // Show only the selected section
    showOnlyActiveSection();
}

function navigateSection(direction) {
    const sections = Object.keys(yamlData).filter(key => key !== 'metadata');
    const currentIndex = sections.indexOf(currentSection);
    const newIndex = Math.max(0, Math.min(sections.length - 1, currentIndex + direction));
    showSection(sections[newIndex]);
}

function updateViewMode() {
    document.querySelectorAll('.cards-grid, .cards-list').forEach(container => {
        container.className = viewMode === 'grid' ? 'cards-grid' : 'cards-list';
    });
    
    // Show/hide global language order selector based on view mode
    const globalOrderSelector = document.getElementById('globalLanguageOrder');
    if (globalOrderSelector) {
        if (viewMode === 'list') {
            globalOrderSelector.classList.add('hidden');
        } else {
            globalOrderSelector.classList.remove('hidden');
        }
    }
    
    document.querySelectorAll('.card').forEach(card => {
        const languageContent = card.querySelector('.language-content');
        const allLanguagesContent = card.querySelector('.all-languages');
        const sliderControls = card.querySelector('.slider-controls');
        
        if (viewMode === 'list') {
            card.classList.add('list-view');
            // Show all languages side by side
            languageContent.style.display = 'none';
            allLanguagesContent.style.display = 'flex';
            sliderControls.style.display = 'none';
        } else {
            card.classList.remove('list-view');
            // Show single language with slider
            languageContent.style.display = 'flex';
            allLanguagesContent.style.display = 'none';
            sliderControls.style.display = 'flex';
        }
    });
}

function filterCards() {
    if (!searchQuery || searchQuery.trim() === '') {
        // If no search query, show only the active section
        showOnlyActiveSection();
        return;
    }
    
    // If there's a search query, search across ALL sections
    const allSections = document.querySelectorAll('.section');
    let totalVisibleCount = 0;
    let searchResults = [];
    
    allSections.forEach(section => {
        const sectionKey = section.id;
        if (sectionKey === 'metadata') return;
        
        const cards = section.querySelectorAll('.card');
        let sectionVisibleCount = 0;
        
        cards.forEach(card => {
            const item = JSON.parse(card.dataset.item);
            const searchMatch = matchesSearchQuery(item, searchQuery);
            
            if (searchMatch) {
                card.style.display = '';
                sectionVisibleCount++;
                totalVisibleCount++;
                
                // Store search result for organizing
                searchResults.push({
                    card: card,
                    section: sectionKey,
                    sectionTitle: formatSectionTitle(sectionKey)
                });
            } else {
                card.style.display = 'none';
            }
        });
        
        // Show section if it has matches, hide if not
        if (sectionVisibleCount > 0) {
            section.classList.add('active');
            section.style.display = 'block';
        } else {
            section.classList.remove('active');
            section.style.display = 'none';
        }
    });
    
    // Remove existing no-results messages
    document.querySelectorAll('.no-results').forEach(el => el.remove());
    
    // Show no results message if needed
    if (totalVisibleCount === 0) {
        const content = document.getElementById('content');
        const noResults = document.createElement('div');
        noResults.className = 'no-results';
        noResults.innerHTML = `
            <span class="no-results-icon">🔍</span>
            <div>No results found for "${searchQuery}"</div>
            <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.7;">Try searching in Thai, English, or phonetic spelling<br>Use commas to search for any of multiple terms (e.g., "hello, สวัสดี")</div>
        `;
        content.appendChild(noResults);
    } else {
        // Update the category selector to show "Search Results"
        const select = document.getElementById('categorySelect');
        if (!select.querySelector('option[value="search_results"]')) {
            const searchOption = document.createElement('option');
            searchOption.value = 'search_results';
            searchOption.textContent = `🔍 Search Results (${totalVisibleCount})`;
            select.insertBefore(searchOption, select.firstChild);
        } else {
            select.querySelector('option[value="search_results"]').textContent = `🔍 Search Results (${totalVisibleCount})`;
        }
        select.value = 'search_results';
        
        // Scroll to search results after a brief delay to ensure DOM updates
        setTimeout(scrollToSearchResults, 100);
    }
}

function showOnlyActiveSection() {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    
    // Show only the current section
    const activeSection = document.getElementById(currentSection);
    if (activeSection) {
        activeSection.classList.add('active');
        activeSection.style.display = 'block';
        
        // Show all cards in the active section
        activeSection.querySelectorAll('.card').forEach(card => {
            card.style.display = '';
        });
    }
    
    // Remove search results option if it exists
    const select = document.getElementById('categorySelect');
    const searchOption = select.querySelector('option[value="search_results"]');
    if (searchOption) {
        searchOption.remove();
    }
    
    // Update select to show current section
    select.value = currentSection;
    
    // Remove any no-results messages
    document.querySelectorAll('.no-results').forEach(el => el.remove());
}

// Removed highlighting functionality as requested

function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Global Language Order Selector Functions
function createGlobalLanguageOrderSelector() {
    const container = document.getElementById('globalLanguageOrder');
    
    const selector = document.createElement('div');
    selector.className = 'language-order-selector';
    selector.id = 'globalSelector';
    
    const title = document.createElement('div');
    title.className = 'order-title';
    title.textContent = 'Language Order';
    
    const itemsContainer = document.createElement('div');
    itemsContainer.className = 'language-items';
    
    // Create draggable items based on current order
    languageOrder.forEach((lang, index) => {
        const item = document.createElement('div');
        item.className = 'language-order-item';
        item.dataset.lang = lang;
        item.draggable = true;
        
        const label = document.createElement('span');
        label.textContent = getLangDisplayName(lang);
        
        const handle = document.createElement('span');
        handle.className = 'drag-handle';
        handle.innerHTML = '⋮⋮';
        
        item.appendChild(label);
        item.appendChild(handle);
        
        // Add drag event listeners
        item.addEventListener('dragstart', handleGlobalDragStart);
        item.addEventListener('dragover', handleDragOver);
        item.addEventListener('drop', handleGlobalDrop);
        item.addEventListener('dragend', handleDragEnd);
        
        itemsContainer.appendChild(item);
    });
    
    selector.appendChild(title);
    selector.appendChild(itemsContainer);
    container.appendChild(selector);
}

function getLangDisplayName(lang) {
    const names = {
        'thai': 'ไทย',
        'english': 'Eng',
        'transliteration': 'Rom'
    };
    return names[lang] || lang;
}

let draggedElement = null;

function handleGlobalDragStart(e) {
    draggedElement = e.target;
    e.target.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    
    if (e.target.classList.contains('language-order-item') && e.target !== draggedElement) {
        e.target.classList.add('drag-over');
    }
}

function handleGlobalDrop(e) {
    e.preventDefault();
    
    if (e.target.classList.contains('language-order-item') && e.target !== draggedElement) {
        const container = e.target.parentNode;
        const draggedIndex = Array.from(container.children).indexOf(draggedElement);
        const targetIndex = Array.from(container.children).indexOf(e.target);
        
        // Reorder the DOM elements
        if (draggedIndex < targetIndex) {
            container.insertBefore(draggedElement, e.target.nextSibling);
        } else {
            container.insertBefore(draggedElement, e.target);
        }
        
        // Update the global language order array
        const newOrder = Array.from(container.children).map(item => item.dataset.lang);
        updateGlobalLanguageOrder(newOrder);
    }
    
    // Remove drag-over class from all items
    document.querySelectorAll('.language-order-item').forEach(item => {
        item.classList.remove('drag-over');
    });
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.language-order-item').forEach(item => {
        item.classList.remove('drag-over');
    });
    draggedElement = null;
}

function updateGlobalLanguageOrder(newOrder) {
    // Update the global language order
    languageOrder = newOrder;
    
    // Update all existing cards to use the new order
    document.querySelectorAll('.card').forEach(card => {
        const cardId = card.dataset.cardId;
        const currentSlide = cardStates[cardId] || 0;
        const item = JSON.parse(card.dataset.item);
        
        // Update the card display with new order
        updateCardDisplay(card, item, currentSlide);
        
        // Update indicators
        updateIndicatorsOrder(card, newOrder);
    });
    
    // Save to localStorage for persistence
    localStorage.setItem('thaiLanguageOrder', JSON.stringify(newOrder));
}

function updateIndicatorsOrder(card, newOrder) {
    const indicators = card.querySelectorAll('.indicator');
    const sliderControls = card.querySelector('.slider-controls');
    
    if (indicators.length === 3 && sliderControls) {
        // Update indicator colors to match new order
        indicators.forEach((indicator, index) => {
            indicator.dataset.lang = newOrder[index];
            // Add visual hint for the order
            const colors = {
                'thai': '#e74c3c',
                'english': '#2c3e50',
                'transliteration': '#8e44ad'
            };
            
            if (!indicator.classList.contains('active')) {
                indicator.style.backgroundColor = colors[newOrder[index]] || '#bdc3c7';
                indicator.style.opacity = '0.6';
            } else {
                indicator.style.backgroundColor = '#667eea';
                indicator.style.opacity = '1';
            }
        });
    }
}

// Utility functions for responsive behavior
function isMobile() {
    return window.innerWidth <= 768;
}

// Handle window resize
window.addEventListener('resize', function() {
    // Update view mode if needed on mobile
    if (isMobile() && viewMode === 'grid') {
        // Auto-switch to list view on mobile for better UX
        const listRadio = document.querySelector('input[name="viewMode"][value="list"]');
        if (listRadio && !listRadio.checked) {
            // Don't auto-switch, let user choose
        }
    }
});

// Add smooth scrolling for navigation
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('nav-btn')) {
        // Smooth scroll to top of content
        document.querySelector('main').scrollIntoView({
            behavior: 'smooth'
        });
    }
});

// Preload audio for better performance
function preloadAudio() {
    // This could be enhanced to preload Thai audio files
    // if you have audio files for each word
}

// Performance optimization: Lazy load cards for large sections
function setupIntersectionObserver() {
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, {
            threshold: 0.1
        });
        
        document.querySelectorAll('.card').forEach(card => {
            observer.observe(card);
        });
    }
}

// Initialize intersection observer after DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(setupIntersectionObserver, 100);
});

// ==================== QUIZ FUNCTIONALITY ====================

let quizState = {
    questions: [],
    currentIndex: 0,
    correctCount: 0,
    wrongCount: 0,
    selectedCategories: [],
    quizType: 'thai-to-english',
    questionCount: 10,
    answerHistory: []
};

function initQuiz() {
    const quizBtn = document.getElementById('quizBtn');
    const quizModal = document.getElementById('quizModal');
    const quizCloseBtn = document.getElementById('quizCloseBtn');
    const quizCloseBtn2 = document.getElementById('quizCloseBtn2');
    const quizCloseBtn3 = document.getElementById('quizCloseBtn3');
    const quizStartBtn = document.getElementById('quizStartBtn');
    const quizNextBtn = document.getElementById('quizNextBtn');
    const quizRetryBtn = document.getElementById('quizRetryBtn');
    const quizNewBtn = document.getElementById('quizNewBtn');
    
    // Open quiz modal
    quizBtn.addEventListener('click', () => {
        openQuizModal();
    });
    
    // Close quiz modal
    [quizCloseBtn, quizCloseBtn2, quizCloseBtn3].forEach(btn => {
        btn.addEventListener('click', closeQuizModal);
    });
    
    // Close on backdrop click
    quizModal.addEventListener('click', (e) => {
        if (e.target === quizModal) {
            closeQuizModal();
        }
    });
    
    // Start quiz
    quizStartBtn.addEventListener('click', startQuiz);
    
    // Next question
    quizNextBtn.addEventListener('click', nextQuestion);
    
    // Retry same quiz
    quizRetryBtn.addEventListener('click', retryQuiz);
    
    // New quiz (go back to setup)
    quizNewBtn.addEventListener('click', () => {
        showQuizScreen('setup');
    });
}

function openQuizModal() {
    const modal = document.getElementById('quizModal');
    modal.classList.add('active');
    populateCategoryCheckboxes();
    showQuizScreen('setup');
}

function closeQuizModal() {
    const modal = document.getElementById('quizModal');
    modal.classList.remove('active');
}

function populateCategoryCheckboxes() {
    const container = document.getElementById('categoryCheckboxes');
    container.innerHTML = '';
    
    const categories = Object.keys(yamlData).filter(key => key !== 'metadata');
    
    // Add "Select All" checkbox
    const selectAllLabel = document.createElement('label');
    selectAllLabel.innerHTML = `
        <input type="checkbox" id="selectAllCategories" checked>
        <strong>📋 Select All</strong>
    `;
    selectAllLabel.style.background = '#667eea';
    selectAllLabel.style.color = 'white';
    selectAllLabel.querySelector('input').addEventListener('change', (e) => {
        const checkboxes = container.querySelectorAll('input[type="checkbox"]:not(#selectAllCategories)');
        checkboxes.forEach(cb => cb.checked = e.target.checked);
    });
    container.appendChild(selectAllLabel);
    
    // Add category checkboxes
    categories.forEach(category => {
        const count = yamlData[category].length;
        const label = document.createElement('label');
        label.innerHTML = `
            <input type="checkbox" value="${category}" checked>
            ${formatSectionTitle(category)} (${count})
        `;
        container.appendChild(label);
    });
}

function showQuizScreen(screen) {
    document.getElementById('quizSetup').style.display = screen === 'setup' ? 'block' : 'none';
    document.getElementById('quizQuestion').style.display = screen === 'question' ? 'block' : 'none';
    document.getElementById('quizResults').style.display = screen === 'results' ? 'block' : 'none';
}

function startQuiz() {
    // Get selected categories
    const checkboxes = document.querySelectorAll('#categoryCheckboxes input[type="checkbox"]:not(#selectAllCategories):checked');
    quizState.selectedCategories = Array.from(checkboxes).map(cb => cb.value);
    
    if (quizState.selectedCategories.length === 0) {
        alert('Please select at least one category!');
        return;
    }
    
    // Get quiz options
    quizState.quizType = document.getElementById('quizType').value;
    const countValue = document.getElementById('quizQuestionCount').value;
    
    // Gather all questions from selected categories
    let allItems = [];
    quizState.selectedCategories.forEach(category => {
        yamlData[category].forEach(item => {
            allItems.push({ ...item, category });
        });
    });
    
    // Shuffle and limit questions
    allItems = shuffleArray(allItems);
    quizState.questionCount = countValue === 'all' ? allItems.length : Math.min(parseInt(countValue), allItems.length);
    quizState.questions = allItems.slice(0, quizState.questionCount);
    
    // Reset state
    quizState.currentIndex = 0;
    quizState.correctCount = 0;
    quizState.wrongCount = 0;
    quizState.answerHistory = [];
    
    // Update UI
    document.getElementById('quizTotalNum').textContent = quizState.questionCount;
    
    showQuizScreen('question');
    displayQuestion();
}

function displayQuestion() {
    const question = quizState.questions[quizState.currentIndex];
    const promptContainer = document.getElementById('quizPrompt');
    const answersContainer = document.getElementById('quizAnswers');
    const feedbackContainer = document.getElementById('quizFeedback');
    const nextBtn = document.getElementById('quizNextBtn');
    
    // Update progress
    document.getElementById('quizCurrentNum').textContent = quizState.currentIndex + 1;
    document.getElementById('correctCount').textContent = quizState.correctCount;
    document.getElementById('wrongCount').textContent = quizState.wrongCount;
    
    // Hide feedback and next button
    feedbackContainer.style.display = 'none';
    nextBtn.style.display = 'none';
    
    // Determine question type
    let questionType = quizState.quizType;
    if (questionType === 'mixed') {
        const types = ['thai-to-english', 'english-to-thai', 'audio-to-thai'];
        questionType = types[Math.floor(Math.random() * types.length)];
    }
    
    // Set up question prompt
    let promptLabel, promptText, promptClass, answerField;
    
    switch (questionType) {
        case 'thai-to-english':
            promptLabel = 'What does this mean?';
            promptText = question.thai;
            promptClass = 'thai';
            answerField = 'english';
            break;
        case 'english-to-thai':
            promptLabel = 'How do you say this in Thai?';
            promptText = question.english;
            promptClass = '';
            answerField = 'thai';
            break;
        case 'audio-to-thai':
            promptLabel = 'Which Thai word sounds like this?';
            promptText = question.transliteration;
            promptClass = '';
            answerField = 'thai';
            break;
    }
    
    promptContainer.innerHTML = `
        <div class="prompt-label">${promptLabel}</div>
        <div class="prompt-text ${promptClass}">${promptText}</div>
    `;
    
    // Generate answer choices with full item data
    const wrongItems = getWrongAnswerItems(question, 3);
    const allItems = shuffleArray([question, ...wrongItems]);
    
    // Store for later reference
    quizState.currentAnswerItems = allItems;
    quizState.currentAnswerField = answerField;
    
    answersContainer.innerHTML = '';
    allItems.forEach((item, index) => {
        const btn = document.createElement('button');
        btn.className = 'quiz-answer-btn';
        btn.dataset.index = index;
        btn.textContent = item[answerField];
        btn.addEventListener('click', () => checkAnswer(btn, item, question, answerField));
        answersContainer.appendChild(btn);
    });
}

function getWrongAnswerItems(currentQuestion, count) {
    const allItems = [];
    const seenEnglish = new Set([currentQuestion.english]);
    
    quizState.selectedCategories.forEach(category => {
        yamlData[category].forEach(item => {
            // Avoid duplicates based on english translation
            if (!seenEnglish.has(item.english)) {
                seenEnglish.add(item.english);
                allItems.push(item);
            }
        });
    });
    
    const shuffled = shuffleArray(allItems);
    return shuffled.slice(0, count);
}

function checkAnswer(btn, selectedItem, correctItem, answerField) {
    const buttons = document.querySelectorAll('.quiz-answer-btn');
    const feedbackContainer = document.getElementById('quizFeedback');
    const nextBtn = document.getElementById('quizNextBtn');
    
    // Disable all buttons
    buttons.forEach(b => b.disabled = true);
    
    // Check if correct
    const isCorrect = selectedItem[answerField] === correctItem[answerField];
    
    if (isCorrect) {
        btn.classList.add('correct');
        quizState.correctCount++;
    } else {
        btn.classList.add('wrong');
        quizState.wrongCount++;
        
        // Highlight correct answer
        buttons.forEach(b => {
            const idx = parseInt(b.dataset.index);
            const item = quizState.currentAnswerItems[idx];
            if (item[answerField] === correctItem[answerField]) {
                b.classList.add('correct');
            }
        });
    }
    
    // Build feedback with all 4 answer details
    const resultText = isCorrect ? '✓ Correct!' : `✗ Wrong! The correct answer was: <strong>${correctItem[answerField]}</strong>`;
    const resultClass = isCorrect ? 'correct' : 'wrong';
    
    let allAnswersHtml = '<div class="quiz-all-answers">';
    quizState.currentAnswerItems.forEach((item, idx) => {
        const isThisCorrect = item[answerField] === correctItem[answerField];
        const isThisSelected = item === selectedItem;
        const translateUrl = `https://translate.google.com/?sl=th&tl=en&text=${encodeURIComponent(item.thai)}&op=translate`;
        
        let itemClass = 'quiz-answer-detail';
        if (isThisCorrect) itemClass += ' correct-answer';
        if (isThisSelected && !isCorrect) itemClass += ' wrong-answer';
        
        allAnswersHtml += `
            <div class="${itemClass}">
                <span class="thai-text">${item.thai}</span>
                <span class="english-text">${item.english}</span>
                <span class="phonetic-text">(${item.transliteration})</span>
                <a href="${translateUrl}" target="_blank" class="quiz-translate-link-small">🔊</a>
            </div>
        `;
    });
    allAnswersHtml += '</div>';
    
    feedbackContainer.className = 'quiz-feedback ' + resultClass;
    feedbackContainer.innerHTML = `${resultText}${allAnswersHtml}`;
    
    // Record answer in history
    quizState.answerHistory.push({
        question: correctItem,
        selectedAnswer: selectedItem,
        isCorrect: isCorrect,
        answerField: answerField
    });
    
    // Update score display
    document.getElementById('correctCount').textContent = quizState.correctCount;
    document.getElementById('wrongCount').textContent = quizState.wrongCount;
    
    // Show feedback and next button
    feedbackContainer.style.display = 'block';
    nextBtn.style.display = 'block';
    nextBtn.textContent = quizState.currentIndex < quizState.questionCount - 1 ? 'Next Question →' : 'See Results 🏆';
}

function nextQuestion() {
    quizState.currentIndex++;
    
    if (quizState.currentIndex >= quizState.questionCount) {
        showResults();
    } else {
        displayQuestion();
    }
}

function showResults() {
    showQuizScreen('results');
    
    const percentage = Math.round((quizState.correctCount / quizState.questionCount) * 100);
    const scoreContainer = document.getElementById('quizFinalScore');
    const messageContainer = document.getElementById('quizResultsMessage');
    
    scoreContainer.innerHTML = `
        ${percentage}%
        <span class="score-label">${quizState.correctCount} / ${quizState.questionCount} correct</span>
    `;
    
    let message, emoji;
    if (percentage === 100) {
        emoji = '🏆';
        message = 'Perfect score! You\'re a Thai master!';
    } else if (percentage >= 80) {
        emoji = '🌟';
        message = 'Excellent! Great job!';
    } else if (percentage >= 60) {
        emoji = '👍';
        message = 'Good work! Keep practicing!';
    } else if (percentage >= 40) {
        emoji = '📚';
        message = 'Not bad! More practice will help!';
    } else {
        emoji = '💪';
        message = 'Keep learning! You\'ll improve!';
    }
    
    messageContainer.innerHTML = `${emoji} ${message}`;
    
    // Build answer summary
    const summaryContainer = document.getElementById('quizAnswerSummary');
    if (summaryContainer) {
        let summaryHtml = '';
        
        quizState.answerHistory.forEach((record, idx) => {
            const q = record.question;
            const translateUrl = `https://translate.google.com/?sl=th&tl=en&text=${encodeURIComponent(q.thai)}&op=translate`;
            const statusIcon = record.isCorrect ? '✓' : '✗';
            const statusClass = record.isCorrect ? 'correct' : 'wrong';
            
            let yourAnswerText = '';
            if (!record.isCorrect) {
                yourAnswerText = `<div class="your-answer">Your answer: ${record.selectedAnswer[record.answerField]}</div>`;
            }
            
            summaryHtml += `
                <div class="summary-item ${statusClass}">
                    <div class="summary-status">${statusIcon}</div>
                    <div class="summary-content">
                        <div class="summary-question">
                            <span class="summary-num">#${idx + 1}</span>
                            <span class="summary-thai">${q.thai}</span>
                        </div>
                        <div class="summary-answer">
                            <span class="summary-english">${q.english}</span>
                            <span class="summary-phonetic">(${q.transliteration})</span>
                        </div>
                        ${yourAnswerText}
                    </div>
                    <a href="${translateUrl}" target="_blank" class="summary-translate">🔊</a>
                </div>
            `;
        });
        
        summaryContainer.innerHTML = summaryHtml;
    }
}

function retryQuiz() {
    // Reset state but keep same questions
    quizState.currentIndex = 0;
    quizState.correctCount = 0;
    quizState.wrongCount = 0;
    quizState.answerHistory = [];
    quizState.questions = shuffleArray(quizState.questions);
    
    showQuizScreen('question');
    displayQuestion();
}

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Initialize quiz when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initQuiz();
});
